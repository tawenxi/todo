# Todo List with Vue.js 

A simple in-browser todo list that saves your todos in Local storage.

Made to make life and day-to-day work a little bit easier! 

[Check it out here!](https://nourabusoud.github.io/vue-todo-list/)
