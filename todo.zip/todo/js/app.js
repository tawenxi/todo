Vue.use(VueResource);

  new Vue({
  el: '#app',
  data() {
    return {
      todoList: [
        {"id":0,
         "ZY":"Go to codepen and get inspired",
         'amount':'',
         'SKR':'',
         'SKZH':'',
         'SKYH':'',
         'ZFFS':'',
         'label':'',
         "done":false,
        },
      ],
      new_todo:{"id":0,
                "ZY":"",
                'amount':'',
                'SKR':'',
                'SKZH':'',
                'SKYH':'',
                'ZFFS':'',
                'label':'',
                "done":false,
        },
      showComplete: false,
    };
  },
  mounted() {
    this.getTodos();
  },
  watch: {
    todoList: {
      handler: function(updatedList) {
        localStorage.setItem('todo_list', JSON.stringify(updatedList));
      },
      deep: true
    }
  },
  computed:{

    pending: function() {
      return this.todoList.filter(function(item) {
        return !item.done;
      })
    },
    completed: function() {
      return this.todoList.filter(function(item) {
        return item.done;
      }); 
    },
    completedPercentage: function() {
      return (Math.floor((this.completed.length / this.todoList.length) * 100)) + "%";
    },
    today: function() {
      var weekday = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
      var today = new Date();
      var dd = today.getDate();
      var mm = today.getMonth()+1; //January is 0!
      var yyyy = today.getFullYear();

      if(dd<10) {
          dd = '0'+dd
      } 

      if(mm<10) {
          mm = '0'+mm
      } 

      today = {
        day: weekday[today.getDay()],
        date:  mm + '-' + dd + '-' + yyyy,
      }

      return(today);
    }
  },
  methods: {
    autoCompleted() {

      var pp= this.pending;
      var bb = [];
            this.$http.get('http://account.test/api/unshengxiao').then(response => {
            response.data.forEach(function(item,index,bb){
                  var a = pp.filter(function($item){
                      return $item.ZY+$item.amount+$item.SKR == item.ZY+(item.JE/100)+item.SKR;
                  });
                  bb.push(a[0]);
                  console.log(bb)
            });

            console.log(this.todoList)
      });
           
 
    },
    autoQs() {
      alert('haha2');
    },
    findSkr(data) {
      this.$http.get('http://account.test/api/boss'+'/'+data).then(response => {
        this.new_todo.SKZH = response.data.bankaccount;
        this.new_todo.SKYH = response.data.bank;
      });
    },
    // get all todos when loading the page
    getTodos() {
      if (localStorage.getItem('todo_list')) {
        this.todoList = JSON.parse(localStorage.getItem('todo_list'));
      }
    },
    // add a new item
    addItem() {
      // validation check
      if (this.new_todo.ZY) {
        this.todoList.unshift({
          id: this.todoList.length,
          ZY: this.new_todo.ZY,
          amount: this.new_todo.amount,
          SKR: this.new_todo.SKR,
          SKYH: this.new_todo.SKYH,
          SKZH: this.new_todo.SKZH,
          ZFFS: this.new_todo.ZFFS,
          label: Date.parse(new Date()),
          done: false,
        });
      }
      // reset new_todo
      this.new_todo = {"id":0,
                "ZY":"",
                'amount':'',
                'SKR':'',
                'SKZH':'',
                'SKYH':'',
                'ZFFS':'',
                'label':'',
                "done":false,
        };

        this.$refs.ZY.focus();
      // save the new item in localstorage
      return true;
    },
    deleteItem(item) {
      this.todoList.splice(this.todoList.indexOf(item), 1);
    },
    toggleShowComplete() {
      this.showComplete = !this.showComplete;
    },
    clearAll() {
      this.todoList = [];
    }
  },
});